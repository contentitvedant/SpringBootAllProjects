package com.cliSocialAnnotation_v3;
public interface Content {
    public void setBody(String body);
    public String getBody();
}

