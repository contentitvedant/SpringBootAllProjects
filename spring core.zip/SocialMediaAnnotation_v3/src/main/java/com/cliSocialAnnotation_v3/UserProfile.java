package com.cliSocialAnnotation_v3;


public interface UserProfile {
    public void setUsername(String username);
    public String getUsername();
    public Content getContent();
    public void setContent(Content content);
}