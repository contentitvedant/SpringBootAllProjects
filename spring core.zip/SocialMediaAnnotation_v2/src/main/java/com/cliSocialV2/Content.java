package com.cliSocialV2;

public interface Content {
    public void setMessage(String message);
    public String getMessage();
}
