package com.cliSocialV1;

public interface Content {
    public void setBody(String message);
    public String getBody();
}
